2 Möglichkeiten an dieser Vorlage zu arbeiten.

1) Mit dem Online Editor Overleaf kann ohne Probleme gearbeitet werden.
	Nach einer Registrierung kann dieser Ordner als .zip hochgeladen werden und los gehts.
	! Es werden ein paar Errors wegen \hl angezeigt, trotzdem ladet die Dokumentation.
	! \hl = Highlight --> wird für die Anmerkungen verwendet.
 
2) Mit dem VSCode kann gearbeitet werden, aber es benötigt an Programmen.
	Download:
	I)	https://strawberryperl.com/
	II)	https://miktex.org/download
	III)	VSCode Extensions:
			a) LaTex Workshop
			b) LaTex language support
			c) Spellcheker
	Hilfe bei Installation: https://www.youtube.com/watch?v=4lyHIQl4VM8&t=603s

Es sollten diese Warnings erscheinen und können vernachlässigt werden. 
1)Auf der Titelseite wegen der Linie in der Mitte.
2)Tabelle 2 wegen den langen Wörtern in der Zelle.


Falls etwas unklar ist, befinden sich viele Infos in den Overleaf Dokumentationen oder Googlen.